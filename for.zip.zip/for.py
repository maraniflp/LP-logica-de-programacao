
print("CALCULADORA DE MULTAS POR ATRASO")

salario = float(input("Digite o valor do salário: R$ "))


dias_atraso = int(input("Digite o número de dias de atraso: "))


if dias_atraso > 5:
    
    multa_por_dia = salario * 0.02
    multa_total = multa_por_dia * dias_atraso
    
    
    print("\n--- RESULTADO ---")
    print(f"Salário: R$ {salario:.2f}")
    print(f"Dias de atraso: {dias_atraso} dias")
    print(f"Multa por dia: R$ {multa_por_dia:.2f} (2% do salário)")
    print(f"Multa total: R$ {multa_total:.2f}")
else:
    
    print("\n--- RESULTADO ---")
    print(f"Salário: R$ {salario:.2f}")
    print(f"Dias de atraso: {dias_atraso} dias")
    print("Não há multa (atraso de 5 dias ou menos)")