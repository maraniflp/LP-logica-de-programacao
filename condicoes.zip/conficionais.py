print("=== VERIFICAÇÃO DE JORNADA DE TRABALHO ===")
horas_trabalhadas = float(input("Digite o total de horas trabalhadas na semana: "))


if horas_trabalhadas > 44:
    print("\nHORAS EXTRAS DETECTADAS!")
    
    horas_extras = horas_trabalhadas - 44
    print(f"Horas extras trabalhadas: {horas_extras}")
    

    valor_hora_normal = float(input("Digite o valor da hora normal (R$): "))
    
    
    valor_hora_extra = valor_hora_normal * 1.5
    
    
    total_horas_extras = horas_extras * valor_hora_extra
    
    
    print(f"\n--- RESULTADO ---")
    print(f"Jornada normal: 44 horas")
    print(f"Horas trabalhadas: {horas_trabalhadas} horas")
    print(f"Horas extras: {horas_extras} horas")
    print(f"Valor da hora normal: R$ {valor_hora_normal:.2f}")
    print(f"Valor da hora extra: R$ {valor_hora_extra:.2f}")
    print(f"Total a pagar pelas horas extras: R$ {total_horas_extras:.2f}")
    
else:
   
    print(f"\n✅ Jornada cumprida corretamente!")
    print(f"Horas trabalhadas: {horas_trabalhadas} horas")
    print(f"Jornada semanal: 44 horas")