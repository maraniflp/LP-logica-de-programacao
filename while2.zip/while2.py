print("CALCULADORA DE FÉRIAS PROPORCIONAIS")


salario = float(input("Digite o salário mensal do trabalhador: R$ "))


meses = int(input("Digite o número de meses trabalhados: "))


ferias = (salario / 12) * meses


print("\n--- RESULTADO ---")
print(f"Salário mensal: R$ {salario:.2f}")
print(f"Meses trabalhados: {meses} meses")
print(f"Férias proporcionais: R$ {ferias:.2f}")